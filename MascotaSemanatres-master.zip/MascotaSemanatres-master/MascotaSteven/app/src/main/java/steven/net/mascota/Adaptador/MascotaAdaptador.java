package steven.net.mascota.Adaptador;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import steven.net.mascota.DetalleMascota;
import steven.net.mascota.R;
import steven.net.mascota.pojo.Mascota;

import java.util.ArrayList;

/**
 * Created by Laia Lechma on 20/05/2016.
 */
public class MascotaAdaptador extends RecyclerView.Adapter<MascotaAdaptador.MascotaViewHolder> {

    ArrayList<Mascota> mascotas;
    Activity activity;

    public MascotaAdaptador (ArrayList<Mascota> mascotas, Activity activity){
        this.mascotas = mascotas;
        this.activity = activity;
      }


    @Override
    public MascotaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view_grid, parent,false);
        return new MascotaViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final MascotaViewHolder mascotaViewHolder, int i) {
        final Mascota mascota = mascotas.get(i);
       // mascotaViewHolder.imgfotoCV.setImageResource(mascota.getFoto());
        Picasso.with(activity)
                .load(mascota.getUrlFoto())
                .placeholder(R.drawable.lobito)
                .into(mascotaViewHolder.imgfotoCV);
        mascotaViewHolder.tvLikes.setText(String.valueOf(mascota.getLikes()));


        mascotaViewHolder.imgfotoCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(activity, DetalleMascota.class);
                intent.putExtra("url" , mascota.getUrlFoto());
                intent.putExtra("like" , mascota.getLikes());
                activity.startActivity(intent);

            }
        });


    }

    @Override
    public int getItemCount() {

        return mascotas.size();
    }

    public static class MascotaViewHolder extends RecyclerView.ViewHolder {

        ImageView imgfotoCV;
        TextView tvLikes;

        public MascotaViewHolder(View itemView) {
            super(itemView);
            imgfotoCV = (ImageView) itemView.findViewById(R.id.imgfotoRetroit);
            tvLikes =(TextView) itemView.findViewById(R.id.tvLikes);

        }


    }
}
