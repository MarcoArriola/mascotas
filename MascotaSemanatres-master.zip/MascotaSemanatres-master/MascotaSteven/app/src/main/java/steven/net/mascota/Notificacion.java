package steven.net.mascota;

import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;

import com.google.firebase.iid.FirebaseInstanceId;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import steven.net.mascota.ResApiWebService.EnpointsServices;
import steven.net.mascota.ResApiWebService.adapterservices.RestApiServicesAdapter;
import steven.net.mascota.ResApiWebService.modelservices.UsuarioResponse;
import steven.net.mascota.restApi.deserializador.MascotaDeserializador;

public class Notificacion extends AppCompatActivity {
    public Toolbar toolbar;
    public TextInputEditText tokenid;
    public TextInputEditText usuario_instagram;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notificacion);


        toolbar = (Toolbar) findViewById(R.id.toolbarNotificacion);
        setSupportActionBar(toolbar);
    }

    public void Recibir (View v){

        String token = FirebaseInstanceId.getInstance().getToken();
        MascotaDeserializador mascotaDeserializador = new MascotaDeserializador();

        enviarTokenRegistro(token);


    }
    public void enviarTokenRegistro(final String token)
    {
        MascotaDeserializador mascotaDeserializador = new MascotaDeserializador();

        Log.d("Token ", token);
        RestApiServicesAdapter restApiServicesAdapter = new RestApiServicesAdapter();
        EnpointsServices enpointsServices = restApiServicesAdapter.establcerConexionesResAPI();
        Call<UsuarioResponse> usuarioResponseCall = enpointsServices.registrarTokenID(token ,"sgalarza");
        usuarioResponseCall.enqueue(new Callback<UsuarioResponse>() {
            @Override
            public void onResponse(Call<UsuarioResponse> call, Response<UsuarioResponse> response) {
                    UsuarioResponse usuarioResponse = response.body();


                //Log.d("Id", usuarioResponse.getId());
               // Log.d("Usuario FIRebase" ,usuarioResponse.getId_dispositivo());
               // Log.d("Usuario Instagram", usuarioResponse.getId_usuario_instagram());

               /* tokenid = (TextInputEditText) findViewById(R.id.tidUsuarioInstagram);
                usuario_instagram = (TextInputEditText) findViewById(R.id.tidIdDispositivo);
                tokenid.setText(usuarioResponse.getId_dispositivo());
                usuario_instagram.setText(usuarioResponse.getId_usuario_instagram());
                */















            }

            @Override
            public void onFailure(Call<UsuarioResponse> call, Throwable t) {
                Log.d("Fallo conexion" ,t.toString() );

            }
        });


    }
}