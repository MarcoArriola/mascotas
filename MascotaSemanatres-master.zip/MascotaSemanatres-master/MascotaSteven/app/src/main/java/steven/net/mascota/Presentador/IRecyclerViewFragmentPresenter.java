package steven.net.mascota.Presentador;

/**
 * Created by Laia Lechma on 28/05/2016.
 */
public interface IRecyclerViewFragmentPresenter {

    public void obtenerMascotasBaseDatos ();

    public void mostrarMascotasRV ();
    public void obtnerMediosRecientes();
}
