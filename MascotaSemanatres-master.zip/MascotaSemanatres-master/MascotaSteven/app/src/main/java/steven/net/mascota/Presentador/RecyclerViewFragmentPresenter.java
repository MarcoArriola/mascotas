package steven.net.mascota.Presentador;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import steven.net.mascota.fragment.IRecycleviewFragmentView;
import steven.net.mascota.pojo.Mascota;
import steven.net.mascota.restApi.EndpointsApi;
import steven.net.mascota.restApi.adapter.RestApiAdapter;
import steven.net.mascota.restApi.model.MascotaResponse;

import java.util.ArrayList;

/**
 * Created by Laia Lechma on 28/05/2016.
 */
public class RecyclerViewFragmentPresenter implements IRecyclerViewFragmentPresenter {

    IRecycleviewFragmentView iRecycleviewFragmentView;
    Context context;
    //ConstructorMascotas constructorMascotas;
    ArrayList<Mascota> mascotas;

    public RecyclerViewFragmentPresenter (IRecycleviewFragmentView iRecycleviewFragmentView, Context context) {
        this.iRecycleviewFragmentView = iRecycleviewFragmentView;
        this.context =context;
        //obtenerMascotasBaseDatos();
         obtnerMediosRecientes();
    }


    @Override
    public void obtenerMascotasBaseDatos() {
            //constructorMascotas = new ConstructorMascotas(context);
           // mascotas = constructorMascotas.obtenerDatos ();
            mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
            iRecycleviewFragmentView.inicializarAdaptadorRV(iRecycleviewFragmentView.crearAdaptador(mascotas));
            iRecycleviewFragmentView.generarLinearLayoutVertical();
    }

    @Override
    public void obtnerMediosRecientes() {
        RestApiAdapter restApiAdapter = new RestApiAdapter();
        Gson gsonMediaRecent = restApiAdapter.construyeGsonDeserializadorMediaRecent();
        EndpointsApi endpointsApi = restApiAdapter.establecerConexionRestApiInstagram(gsonMediaRecent);

        Call <MascotaResponse> mascotaResponseCall = endpointsApi.getRecentMedia();

        mascotaResponseCall.enqueue(new Callback<MascotaResponse>() {
            @Override
            public void onResponse(Call<MascotaResponse> call, Response<MascotaResponse> response) {
                MascotaResponse mascotaResponse = response.body();
                mascotas = mascotaResponse.getMascotas();
                mostrarMascotasRV();

            }

            @Override
            public void onFailure(Call<MascotaResponse> call, Throwable t) {
                Toast.makeText(context, "Fallo Conexion", Toast.LENGTH_LONG).show();
                Log.e("Fallo conexion," ,t.toString());

            }

        });




    }
}
