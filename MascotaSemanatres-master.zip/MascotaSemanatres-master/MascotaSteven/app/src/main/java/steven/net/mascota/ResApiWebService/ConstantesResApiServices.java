package steven.net.mascota.ResApiWebService;

/**
 * Created by steven on 10/07/16.
 */
public final class ConstantesResApiServices {

    public static final String ROOT_URL = "https://barcelonaecuador.herokuapp.com/";
    public static final String KEY_POST_ID_TOKEN = "registrar-usuario/";
    public static final String KEY_REGISTRAR_LIKES = "registrar-likes/";
    public static final String KEY_ENVIAR_NOTIFICACION ="enviar-notificacion";
}
