package steven.net.mascota.ResApiWebService;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import steven.net.mascota.ResApiWebService.modelservices.LikeResponse;
import steven.net.mascota.ResApiWebService.modelservices.UsuarioResponse;

/**
 * Created by steven on 10/07/16.
 */
public interface EnpointsServices {

    @FormUrlEncoded
    @POST(ConstantesResApiServices.KEY_POST_ID_TOKEN)
    Call<UsuarioResponse> registrarTokenID(@Field("id_dispositivo") String id_dispositivo , @Field("id_usuario_instagram") String id_usuario_instagram);


    @FormUrlEncoded
    @POST(ConstantesResApiServices.KEY_REGISTRAR_LIKES)
    Call<LikeResponse> registrarLikes(@Field("id_dispositivo") String id_dispositivo , @Field("id_usuario_instagram") String id_usuario_instagram, @Field("id_foto_instagram") String id_foto_instagram);

    @GET(ConstantesResApiServices.KEY_ENVIAR_NOTIFICACION)
    Call<LikeResponse> enviarNotificacion(@Path("id") String id , @Path("id_dispositivo") String id_dispositivo);



}
