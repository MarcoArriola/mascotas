package steven.net.mascota.ResApiWebService.adapterservices;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import steven.net.mascota.ResApiWebService.ConstantesResApiServices;
import steven.net.mascota.ResApiWebService.EnpointsServices;

/**
 * Created by steven on 10/07/16.
 */
public class RestApiServicesAdapter {

    public EnpointsServices establcerConexionesResAPI(){

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ConstantesResApiServices.ROOT_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(EnpointsServices.class);

    }
}
