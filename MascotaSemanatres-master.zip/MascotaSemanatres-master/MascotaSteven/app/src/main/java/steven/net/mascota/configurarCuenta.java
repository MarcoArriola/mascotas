package steven.net.mascota;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class configurarCuenta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configurar_cuenta);
    }
}
