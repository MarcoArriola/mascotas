
package steven.net.mascota.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import steven.net.mascota.R;
import steven.net.mascota.pojo.Mascota;

import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentPerfil extends Fragment {

    ArrayList<Mascota> mascotas;
    RecyclerView listMascotas;
    CircularImageView circularImageView;
    TextView tvNombre;

    public FragmentPerfil() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_perfil, container, false);

        //CircularImageView circularImageView = (CircularImageView)v.findViewById(R.id.civPerfil);
       // tvNombre = (TextView) v.findViewById(R.id.tvNombrePerfil);


        /* LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.HORIZONTAL);*/


        listMascotas = (RecyclerView) v.findViewById(R.id.rvMascotasperfil);
        listMascotas.setClickable(false);
        listMascotas.setEnabled(false);
        listMascotas.setLayoutFrozen(true);
        listMascotas.setItemAnimator(new DefaultItemAnimator());

        GridLayoutManager glm = new GridLayoutManager(getActivity(),3);

        listMascotas.setLayoutManager(glm);
        inicializarListMascotas();
       // inicializarAdaptador();

        return v;
    }
    //public ActivityContacta.MascotaAdaptador adaptador;
    /*public void inicializarAdaptador(){
        ActivityContacta.MascotaAdaptador adaptador = new ActivityContacta.MascotaAdaptador(mascotas);
        listMascotas.setAdapter(adaptador);
    }*/

    public void inicializarListMascotas(){
        mascotas = new ArrayList<Mascota>();
       // mascotas.add (new Mascota(R.drawable.lobo1,"","","","","", 20));
       // mascotas.add (new Mascota(R.drawable.lobo2,"","","","","", 3));
        //mascotas.add (new Mascota(R.drawable.lobo3,"","","","","", 5));
    }

}
