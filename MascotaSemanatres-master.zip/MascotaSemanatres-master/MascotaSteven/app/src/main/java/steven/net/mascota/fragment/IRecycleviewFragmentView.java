package steven.net.mascota.fragment;

import steven.net.mascota.Adaptador.MascotaAdaptador;
import steven.net.mascota.pojo.Mascota;

import java.util.ArrayList;

/**
 * Created by Laia Lechma on 26/05/2016.
 */
public interface IRecycleviewFragmentView {

    public void generarLinearLayoutVertical ();

    public MascotaAdaptador crearAdaptador (ArrayList<Mascota> mascotas);

    public void inicializarAdaptadorRV (MascotaAdaptador adaptador);
    void obtenerMediosRecientes();

}
