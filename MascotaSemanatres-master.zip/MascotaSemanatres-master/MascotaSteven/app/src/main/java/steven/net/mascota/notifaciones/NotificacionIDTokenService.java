package steven.net.mascota.notifaciones;

import com.google.firebase.iid.FirebaseInstanceId;
import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

/**
 * Created by steven on 03/07/16.
 */
public class NotificacionIDTokenService extends FirebaseInstanceIdService {

        public static final String TAG = "FIREBASE_TOKEN";
    @Override
    public void onTokenRefresh() {
        Log.d(TAG , "Solicitando token");
        String token = FirebaseInstanceId.getInstance().getToken();
        enviarTokenRegistro(token);
    }

    private  void enviarTokenRegistro(String token){
        Log.d(TAG,token);
    }
}
