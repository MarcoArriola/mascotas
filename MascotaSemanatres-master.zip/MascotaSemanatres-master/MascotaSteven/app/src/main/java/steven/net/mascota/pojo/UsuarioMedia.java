package steven.net.mascota.pojo;

/**
 * Created by steven on 11/07/16.
 */
public class UsuarioMedia {

    private String userid;
    private String urlFotoPerfil;

    private int likes =0;
}
