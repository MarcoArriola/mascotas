package steven.net.mascota.restApi;


public final class ConstantesRestApi {

    //https://api.instagram.com/v1/
    public static final String VERSION = "/v1/";
    public static final String ROOT_URL = "https://api.instagram.com" + VERSION;
    public static final String ACCESS_TOKEN = "3462057579.6706a86.315e734e5d124504acc185a8f88dc222";
    public static final String KEY_ACCESS_TOKEN = "?access_token=";
    public static final String KEY_GET_RECENT_MEDIA_USER = "users/self/media/recent/";
    public static final String URL_GET_RECENT_MEDIA_USER = KEY_GET_RECENT_MEDIA_USER + KEY_ACCESS_TOKEN + ACCESS_TOKEN;

    //https://api.instagram.com/v1/users/self/media/recent/?access_token=3462057579.6706a86.315e734e5d124504acc185a8f88dc222

    public static final String KEY_URL_GET_USERID ="users/search?q=";
    public static final String KEY_URL_GET_USERS = "users/" ;
    public static final String KEY_URL_GET_MEDIA_RECENT = "/media/recent";


}
