package steven.net.mascota.restApi.model;


import java.util.ArrayList;

import steven.net.mascota.pojo.Mascota;

/**
 * Created by anahisalgado on 25/05/16.
 */
public class MascotaResponse {

    ArrayList<Mascota> mascotas;

    public ArrayList<Mascota> getMascotas() {
        return mascotas;
    }

    public void setContactos(ArrayList<Mascota> mascotas) {
        this.mascotas = mascotas;
    }
}
