package steven.net.mascota.restApi.model;

import java.util.ArrayList;

import steven.net.mascota.pojo.UsuarioMedia;

/**
 * Created by steven on 11/07/16.
 */
public class UsuarioMediaResponse {
    UsuarioMedia usuarioMedia;

    public UsuarioMedia getUsuarioMedia() {
        return usuarioMedia;
    }

    public void setUsuarioMedia(UsuarioMedia usuarioMedia) {
        this.usuarioMedia = usuarioMedia;
    }
}
