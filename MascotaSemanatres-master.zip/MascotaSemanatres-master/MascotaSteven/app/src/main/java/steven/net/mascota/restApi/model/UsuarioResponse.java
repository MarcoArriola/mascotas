package steven.net.mascota.restApi.model;

import java.util.ArrayList;

import steven.net.mascota.pojo.Usuario;

/**
 * Created by steven on 11/07/16.
 */
public class UsuarioResponse {

    ArrayList<Usuario> usuarios;


    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(ArrayList<Usuario> usuarios) {
        this.usuarios = usuarios;
    }
}
