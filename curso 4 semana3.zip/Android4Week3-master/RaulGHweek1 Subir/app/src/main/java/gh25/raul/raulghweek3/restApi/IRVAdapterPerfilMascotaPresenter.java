package gh25.raul.raulghweek3.restApi;

/**
 * Created by Raul on 25/06/2016.
 */
public interface IRVAdapterPerfilMascotaPresenter {

    public void obtenerDataReciente();

}
